# MOD
x = 5
y = 2

z = 5 % 2

print(z)

# Exponenciação
x = 5
y = 2

z = 5 ** 2

print(z)

# Divisão inteira
x = 5
y = 2

z = 5 // 2

print(z)
