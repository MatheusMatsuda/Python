"""
print("Bom dia", end="")
print("Boa noite")
"""

"""
x = "Maria"
y = 19

print("%s tem % d anos" % (x , y))
"""

"""
x: int; y: int
x = 10
y = 20
print(x)
print(y)
"""

"""
x: float
x = 2.2323
print("{:.2f}".format(x))
"""

idade: int
salario: float
sexo: str
nome: str

idade = 32
salario = 4560.9
sexo = "F"
nome = "Maria Silva"

print(f"A funcionaria {nome}, {sexo}, ganha {salario:.2f} e tem {idade}")