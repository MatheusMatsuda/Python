"""
x: int; y:int
x = 5
y = 2 * x
print(x)
print(y)
"""

"""
b1: float; b2: float; h: float; area: float
b1 = 6.0
b2 = 8.0
h = 5.0
area = (b1 + b2) / 2.0 * h
print(area)
"""

"""
a: int; b: int
a = 5
b = 2
resultado = a / b
print(resultado)
"""

"""
a: float
b: int

a = 5.2
b = a
print(b)
"""

a: float
b: int

a = 5.2
b = int(a)
print(b)