x = int(input("Digite x: "))
y = 2 * x
print(f"Valor de y = {y}")
z = int(input("Digite z: "))
print(f"Valor de z = {z}")
w = 5 + z
print(f"Valor de w = {w}")

